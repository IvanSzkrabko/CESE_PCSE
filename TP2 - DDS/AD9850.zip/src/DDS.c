/*=============================================================================
 * Copyright (c) 2020, IvanSzkrabko <ivanleonelszk@gmail.com>
 * All rights reserved.
 * License: mit (see LICENSE.txt)
 * Date: 2020/09/12
 *===========================================================================*/

/*=====[Inclusions of function dependencies]=================================*/
#include "DDS.h"
/*=====[Definition macros of private constants]==============================*/

/*=====[Definitions of extern global variables]==============================*/

/*=====[Definitions of public global variables]==============================*/

/*=====[Definitions of private global variables]=============================*/

double frequency = 10000000;	//32 bit
int phase = 0;					//5 bit - 32 valores - de 0 a 360 en pasos de 11,25°
uint32_t calibfreq = 124999500;
uint32_t finalfrec;

/*===========================================================================*/

void DDS_setPins (void ){

	uint32_t modoSalida = SCU_MODE_INACT | SCU_MODE_INBUFF_EN |  SCU_MODE_ZIF_DIS;

	//w_clk:GPIO0    fq_ud:GPIO2    data:GPIO4    reset:GPIO6

	//Configuración para SALIDA
	Chip_SCU_PinMux( 6 , 1 , modoSalida , FUNC0 ); //GPIO0
	Chip_SCU_PinMux( 6 , 5 , modoSalida , FUNC0 ); //GPIO2
	Chip_SCU_PinMux( 6 , 8 , modoSalida , FUNC4 ); //GPIO4
	Chip_SCU_PinMux( 6 , 10 , modoSalida , FUNC0 ); //GPIO6

	//Configuración para SALIDA
	Chip_GPIO_SetDir( LPC_GPIO_PORT, 3, ( 1<<0 ), OUTPUT);//GPIO0
	Chip_GPIO_SetDir( LPC_GPIO_PORT, 3, ( 1<<4 ), OUTPUT);//GPIO2
	Chip_GPIO_SetDir( LPC_GPIO_PORT, 5, ( 1<<16 ), OUTPUT);//GPIO4
	Chip_GPIO_SetDir( LPC_GPIO_PORT, 3, ( 1<<6 ), OUTPUT);//GPIO6

	//init
	reset_w_clk;
	reset_fq_ud;
	reset_data;
	reset_reset;

	delay(10000);

	//seteo serial mode
	set_reset;
	delay(demoras);
	reset_reset;
	delay(demoras);

	set_w_clk;
	delay(demoras);
	reset_w_clk;
	delay(demoras);

	set_fq_ud;
	delay(demoras);
	reset_fq_ud;
	delay(demoras);

}


void DDS_shift (uint32_t numero){

	for(uint8_t i=0 ;i<8;i++,numero>>=1){ //shifteo a la derecha un bit

		bool_t bit_numero = numero & 0x01;

		if(bit_numero==1)
			set_data;
		else
			reset_data;

		#ifdef debug_on
		printf("bit:%i \n",bit_numero);
		#endif

		set_w_clk;
		#ifdef debug_on
		printf("set_w_clk \n");
		#endif

		reset_w_clk;
		#ifdef debug_on
		printf("reset_w_clk \n");
		#endif
	}

}

void DDS_setFreq (uint32_t freq , uint8_t phase){

  finalfrec= freq * 4294967296.0 / calibfreq;
  phase = phase << 3; //w32-w33-w34

  #ifdef debug_on
  printf("Freq: %u \n",freq);
  #endif

  for (uint8_t i=0; i<4; i++, finalfrec>>=8) {//w0-w31
	  DDS_shift(finalfrec);
   }

  DDS_shift(phase);//w35-w39
  set_fq_ud;
  #ifdef debug_on
  printf("set_fq_ud \n");
  #endif

  reset_fq_ud;
  #ifdef debug_on
  printf("reset_fq_ud \n");
  #endif


}

uint32_t DDS_sweep (uint32_t start, uint32_t end, uint32_t steps){

	uint32_t limit=0;

	limit=(end-start)/steps;

	if(end>start && limit>0)
	{
		DDS_setFreq (start, 0);
		delay(hold);

		for(uint32_t i=0;i<limit;i++)
		{
			start+=steps;
			DDS_setFreq (start, 0);
			delay(hold);
		}
		return 1;//end successfully
	}
	return 0;//error
}

