/*=============================================================================
 * Copyright (c) 2020, IvanSzkrabko <ivanleonelszk@gmail.com>
 * All rights reserved.
 * License: mit (see LICENSE.txt)
 * Date: 2020/09/12
 *
 *
 * w_clk : Working clock output pin, any pin (int)
 * fq_ud : Frequency update pin, any pin. (int)
 * data : Serial data output pin, any pin (int)
 * reset : Reset output pin, any pin. (int)
 *===========================================================================*/

/*=====[Avoid multiple inclusion - begin]====================================*/

#ifndef __DDS_H__
#define __DDS_H__

/*=====[Inclusions of public function dependencies]==========================*/
#include "sapi.h"
#include "scu_18xx_43xx.h"
#include "gpio_18xx_43xx.h"
#include "chip.h"

/*=====[C++ - begin]=========================================================*/

#ifdef __cplusplus
extern "C" {
#endif

/*=====[Definition macros of public constants]===============================*/
#define set_w_clk Chip_GPIO_SetPinState( LPC_GPIO_PORT, 3, 0, TRUE)//GPIO0
#define set_fq_ud Chip_GPIO_SetPinState( LPC_GPIO_PORT, 3, 4, TRUE)//GPIO2
#define set_data Chip_GPIO_SetPinState( LPC_GPIO_PORT, 5, 16, TRUE)//GPIO4
#define set_reset Chip_GPIO_SetPinState( LPC_GPIO_PORT, 3, 6, TRUE)//GPIO6

#define reset_w_clk Chip_GPIO_SetPinState( LPC_GPIO_PORT, 3, 0, FALSE)//GPIO0
#define reset_fq_ud Chip_GPIO_SetPinState( LPC_GPIO_PORT, 3, 4, FALSE)//GPIO2
#define reset_data Chip_GPIO_SetPinState( LPC_GPIO_PORT, 5, 16, FALSE)//GPIO4
#define reset_reset Chip_GPIO_SetPinState( LPC_GPIO_PORT, 3, 6, FALSE)//GPIO6

#define OUTPUT 1
#define demoras 1
#define hold 5000

//#define debug_on


/*=====[Public function-like macros]=========================================*/

/*=====[Definitions of public data types]====================================*/

/*=====[Prototypes (declarations) of public functions]=======================*/

void DDS_setPins(void);
void DDS_setFreq (uint32_t frecuencia, uint8_t fase);
void DDS_shift (uint32_t word);
uint32_t DDS_sweep (uint32_t f_inicio,uint32_t f_fin,uint32_t saltos);

/*=====[Prototypes (declarations) of public interrupt functions]=============*/

/*=====[Avoid multiple inclusion - end]======================================*/

#endif /* __DDS_H__ */
